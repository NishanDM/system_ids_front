// src/api/jobApi.js
const BASE_URL = "http://localhost:5000/api/jobs";
